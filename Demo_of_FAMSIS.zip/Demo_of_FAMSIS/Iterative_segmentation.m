function Detection_result = Iterative_segmentation(Detection_score,alpha_segmentation,belta_segmentation)

[row,col] = size(Detection_score);
Detection_result = zeros(row,col);
global_mean = mean(Detection_score(find(Detection_score>0)));
seg_flag = 1;
loop = 1;
while seg_flag == 1   % 
%     score_index = find(Detection_score>0);
    [max_score,max_index] = max(Detection_score(:));
    % 
    max_location_row =  mod(max_index,row);                       % 
    if max_location_row==0
        max_location_row = row;
    end
    max_location_col = ((max_index-max_location_row)/row) +1;     %  
    % 
    score_index = find(Detection_score>0);
    score_mean = mean(Detection_score(score_index));
    score_std = std(Detection_score(score_index));
    % 
    beta = belta_segmentation;
    seg_TH = score_mean+beta*score_std;

    alpha = alpha_segmentation;
    if max_score >= alpha*global_mean
        Detection_result(max_location_row,max_location_col) = 1;  % 
        Detection_score(max_location_row,max_location_col) = 0;
    elseif max_score >= seg_TH
        Detection_result(max_location_row,max_location_col) = 1;  % 
        Detection_score(max_location_row,max_location_col) = 0;  % 
    else % 
        seg_flag = 0;
    end

    % 
    loop = loop+1;
end % 

end