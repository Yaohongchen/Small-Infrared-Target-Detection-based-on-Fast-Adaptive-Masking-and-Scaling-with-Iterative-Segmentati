function Add_circle_for_target(Detection_result)

[row,col]=size(Detection_result);
mask = imbinarize(double(Detection_result),0.000001); % 
Conn_struct = bwconncomp(mask); % 
for i=1:Conn_struct.NumObjects
    Conn_temp = Conn_struct.PixelIdxList(i);
    Conn_index = [Conn_temp{1,1}];          % 
    [Conn_num no_use]= size(Conn_index);    % 
    if Conn_num>1
        for j=1:Conn_num                        % 
            Conn_position(j,1) = mod(Conn_index(j,1),row); % 
            Conn_position(j,2) = ((Conn_index(j,1)-Conn_position(j,1))/row) +1; %          
        end
        min_position = min(Conn_position);
        max_position = max(Conn_position);
        max_row = max_position(1);
        min_row = min_position(1);
        max_col = max_position(2); 
        min_col = min_position(2);
        height = (max_row-min_row)+1;
        width = (max_col-min_col)+1;
        center_row = (max_row+min_row)/2;
        center_col = (max_col+min_col)/2;       % 
    else
        Conn_position(1,1) = mod(Conn_index,row);
        Conn_position(1,2) = ( (Conn_index-Conn_position(1,1)) /row) +1;
        min_row = Conn_position(1,1);
        min_col = Conn_position(1,2);       % 
        center_row = Conn_position(1,1);
        center_col = Conn_position(1,2);       % 
        height = 1;
        width = 1;
        circle_row = Conn_position(1,1);
        circle_col = Conn_position(1,2); 
    end

    d = max(height,width)+3;                % 
    r = d/2;
    
    for k = 1:Conn_num 
        distance(k) = (Conn_position(k,1)-center_row)^2 + (Conn_position(k,2)-center_col)^2;
    end
    
    [min_distance_value,min_distance_index] = min(distance);
    circle_row = Conn_position(min_distance_index,1);
    circle_col = Conn_position(min_distance_index,2);
    hold on;
%     plot(circle_col, circle_row,  'LineStyle', 'none', 'LineWidth', 0.75, 'Color', 'y', 'Marker', 'o', 'MarkerSize', d);    

	rectangle('position',[circle_col-r,circle_row-r,d ,d],'curvature',[1,1],'edgecolor','y','LineWidth', 0.75);

    clear d; clear distance; clear Conn_temp; clear Conn_index; clear j; clear k; clear Conn_position;
    clear height; clear width;  
end

hold off;

end