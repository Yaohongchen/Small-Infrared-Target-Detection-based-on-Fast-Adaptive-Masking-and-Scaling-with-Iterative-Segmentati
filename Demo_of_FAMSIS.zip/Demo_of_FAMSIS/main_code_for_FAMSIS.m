%% This code is a demo of our paper: Yaohong Chen, et al. "Small Infrared Target Detection based on Fast Adaptive Masking and Scaling with Iterative Segmentation." IEEE Geosci. Remote Sens. Lett., 2020
% If you use this code of FAMSIS for your work, please cite our paper.
% The volume and issue information will available in a few months.
% @article{
%    author = {Yaohong Chen, Gaopeng Zhang, Yingjun Ma, Jin U. Kang, and Chiman Kwan},
%    title = {Small Infrared Target Detection based on Fast Adaptive Masking and Scaling with Iterative Segmentation},
%    journal = {IEEE Geoscience and Remote Sensing Letters},
%    volume = {  },
%    number = {  },
%    pages = {  },
%    month = {  },
%    year = {2021}
%    link: https://ieeexplore.ieee.org/document/9328154
%    Print ISSN: 1545-598X
%    Online ISSN: 1558-0571
%    Digital Object Identifier: 10.1109/LGRS.2020.3047524
% }

%% Please change the path according to your save path!!!
clear all;
close all;
clc;
path = 'D:\IR_STD\Demo_of_FAMSIS\';   % Please change the path according to your save path
cd (path);

%% It should be noted that minor revision is required for sequence test
input_path  = ('input_images/');
output_path = ('results/');
image_index = dir([input_path '*.png']);
image_num   = length(image_index);

% Definition of the DoG filter
sigma1 = 1.06;
sigma2 = 2.47;  % sigma2 = 2.71;  sigma2 equals 2.71 also works well 
window = 5;
H1 = fspecial('gaussian', window, sigma1);
H2 = fspecial('gaussian', window, sigma2);
DiffGauss = H1-H2;

%% Detection
for k=1:image_num
    % load image
    I_in = double(imread([input_path,image_index(k).name]));
    [row col] = size(I_in);
    % running time
    tic;
    
    %% Phase 1
    % DoG filter in phase 1
    S_map = imfilter(I_in,DiffGauss,'replicate');  % figure(); imshow(S_map,[]),impixelinfo; title('DoG result');

    % CDF
    S_map_norm = round(99.*mat2gray(S_map));            % figure();histogram(S_map_norm);
    Hist_S_map_norm = zeros(1,100);
    for i = 1:row
        for j = 1:col
            Hist_S_map_norm(S_map_norm(i,j)+1) = Hist_S_map_norm(S_map_norm(i,j)+1) +1; % ֱ��ͼ
        end
    end
    cum_hist = sum(Hist_S_map_norm);        
    CDF_S_map = cumsum(Hist_S_map_norm)/cum_hist;       % CDF
    
    % mask generation
    TH_CDF_clip = 0.998;
    TH_S_map_norm_clip = find(CDF_S_map >= TH_CDF_clip, 1, 'first');  % �ҵ����ڵ�����ֵ�ĵ�һ���ҽ�
    S_map_B = double(imbinarize(S_map_norm, TH_S_map_norm_clip));     % figure(); imshow(S_map_B,[]),impixelinfo; title('Mask');
    
    %% Phase 2, generation of the local contrast map, local gradient map and detection score
    [SCR_map,Gradient_map] = Morphology_analysis(I_in,S_map,S_map_B);
    Detection_score = SCR_map.*Gradient_map;
    Detection_time = toc

    %% Phase 3��segmentation. It should be noted that the alpha and belta are customer selected parameters ranging from 2 to 5
    %% The alpha and belta are fixed if the input images belong to the same sequence, The if / else judgement are not required for sequence test!!!
    temp_name = image_index(k).name;
    if str2num(temp_name(2)) == 1 % for S1
        alpha_segmentation = 3;
        belta_segmentation = 3;
        tic;
        Detection_result = Iterative_segmentation(Detection_score,alpha_segmentation,belta_segmentation);
        Segmentation_time = toc
    elseif str2num(temp_name(2)) == 2 % for S2
        alpha_segmentation = 3;
        belta_segmentation = 5;
        tic;
        Detection_result = Iterative_segmentation(Detection_score,alpha_segmentation,belta_segmentation);
        Segmentation_time = toc
    elseif str2num(temp_name(2)) == 3 % for S3
        alpha_segmentation = 3;
        belta_segmentation = 4;
        tic;
        Detection_result = Iterative_segmentation(Detection_score,alpha_segmentation,belta_segmentation);
        Segmentation_time = toc
    elseif str2num(temp_name(2)) == 4 % for S4
        alpha_segmentation = 3;
        belta_segmentation = 5;
        tic;
        Detection_result = Iterative_segmentation(Detection_score,alpha_segmentation,belta_segmentation);
        Segmentation_time = toc
    else % other sequences
      
    end    
    
    %% output
    figure('Visible','off');
    subplot(2,3,1); imshow(I_in,[0 255]); title('Input'); 
    subplot(2,3,2); imshow(S_map_B,[]); title('mask'); 
    subplot(2,3,3); imshow(SCR_map,[]); title('Contrast map'); 
    subplot(2,3,4); imshow(Gradient_map,[]); title('Gradient map'); 
    subplot(2,3,5); imshow(Detection_score,[]); title('Detection score'); 
    subplot(2,3,6); imshow(Detection_result,[]); title('Segmentation'); Add_circle_for_target(Detection_result);
    saveas(gcf, [output_path,temp_name(1:(length(temp_name)-4)),'.png']);
end    
  