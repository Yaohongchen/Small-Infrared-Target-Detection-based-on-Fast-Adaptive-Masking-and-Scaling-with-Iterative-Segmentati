function G_value = Gradient_analysis_morphology(Input)

%% 
S_0 = [-1 1];        D_0 = filter2(S_0,Input,'valid');       % 0
S_45 = [0,1;-1,0];   D_45 = filter2(S_45,Input,'valid');     % 45
S_90 = [1;-1];       D_90 = filter2(S_90,Input,'valid');     % 90
S_135 = [1,0;0,-1];  D_135 = filter2(S_135,Input,'valid');   % 135
% S_180 = [1 -1];      D_180 = filter2(S_180,Input,'valid');   % 180
% S_225 = [0,-1;1,0];  D_225 = filter2(S_225,Input,'valid');   % 225
% S_270 = [-1;1];      D_270 = filter2(S_270,Input,'valid');   % 270
% S_315 = [-1,0;0,1];  D_315 = filter2(S_315,Input,'valid');   % 315

%% 
G_value_0 = sum(D_0(:));
G_value_45 = sum(D_45(:));
G_value_90 = sum(D_90(:));
G_value_135 = sum(D_135(:));

G_value_180 = -G_value_0;
G_value_225 = -G_value_45;
G_value_270 = -G_value_90;
G_value_315 = -G_value_135;

G_value = [G_value_0,G_value_45,G_value_90,G_value_135,G_value_180,G_value_225,G_value_270,G_value_315];


end
