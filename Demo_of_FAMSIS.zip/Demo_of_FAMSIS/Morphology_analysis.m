%% 
function [SCR_map,Gradient_map] = Morphology_analysis(I_in,S_map,S_map_B)
% figure(); imshow(S_map_B),impixelinfo;
[row,col]=size(S_map_B);
% 
Conn_struct = bwconncomp(S_map_B); 
% 
SCR_map = zeros(row,col);
Gradient_map = zeros(row,col);

%% 
for i=1:Conn_struct.NumObjects
    Conn_temp = Conn_struct.PixelIdxList(i);
    Conn_index = [Conn_temp{1,1}];          % 
    [Conn_num no_use]= size(Conn_index);    % 
    clear Conn_position;                    % 
    
    % 
	for j=1:Conn_num                        
        Conn_position(j,1) = mod(Conn_index(j,1),row);                      % 
        if Conn_position(j,1)==0
            Conn_position(j,1) = row;
        end
        Conn_position(j,2) = ((Conn_index(j,1)-Conn_position(j,1))/row) +1; %            
    end
    
    %% 
    if Conn_num>1   % 
        min_position = min(Conn_position);
        max_position = max(Conn_position);
        max_row = max_position(1);
        min_row = min_position(1);
        max_col = max_position(2); 
        min_col = min_position(2);   
        % 
        range_row = max_row-min_row+1;              % 
        range_col = max_col-min_col+1;              % 
        range_limit = min(range_row,range_col)+1;   % 
        % 
        Conn_patch = S_map_B(min_row:max_row,min_col:max_col);
        scale_flag = zeros(1,range_limit);          % 
        % 
        for k = 2:range_limit                       
            scale_filter = ones(k,k);
            scale_filter_result = conv2(Conn_patch,scale_filter,'valid'); % 
            % 
            scale_judge_TH = k*(k-1)+1;
            if length( find(scale_filter_result>=scale_judge_TH) )>0
                scale_flag(1,k) = 1;                % 
            else
                scale_flag(1,2) = 1;                % 
            end
        end
        % 
        scale_index = find(scale_flag>0);
        scale_factor = max(scale_index)+mod(max(scale_index)-1,2);  %      
    else            %      
        scale_factor = 3;                    % 
    end
    
    %% 
    win_size = scale_factor*3;             % 
    r_win = (win_size-1)/2;
    r_target = (scale_factor-1)/2;
    win_center = r_win+1;
    mask_outer = ones(win_size,win_size);
    mask_outer(win_center-r_target:win_center+r_target,win_center-r_target:win_center+r_target) = 0;
    mask_inner = (ones(win_size,win_size)) - mask_outer;
    
    %% 
    for j=1:Conn_num 
        % 
        if ( (Conn_position(j,1)-r_win)>0 & (Conn_position(j,1)+r_win)<=row & (Conn_position(j,2)-r_win)>0 & (Conn_position(j,2)+r_win)<=col) ==1
            patch_SCR = S_map(Conn_position(j,1)-r_win:Conn_position(j,1)+r_win,Conn_position(j,2)-r_win:Conn_position(j,2)+r_win); 
            target = patch_SCR.*mask_inner;
            target_v = target(find(mask_inner>0));          % 
            background = patch_SCR.*mask_outer;
            background_v = background(find(mask_outer>0));  % 
            mean_T = mean(target_v);
            mean_B = mean(background_v);
            std_B = std(background_v);
%             SCR_map(Conn_position(j,1),Conn_position(j,2)) = (mean_T-mean_B)/std_B;
            SCR_map(Conn_position(j,1),Conn_position(j,2)) = (mean_T-mean_B)^2/std_B;
        end
    end
    
    %% 
    for j=1:Conn_num 
        % 
        if ( (Conn_position(j,1)-r_win)>0 & (Conn_position(j,1)+r_win)<=row & (Conn_position(j,2)-r_win)>0 & (Conn_position(j,2)+r_win)<=col) ==1
            % 
            patch_quadrant_R_U = I_in(Conn_position(j,1)-r_win:Conn_position(j,1), Conn_position(j,2):Conn_position(j,2)+r_win);
            patch_quadrant_L_U = I_in(Conn_position(j,1)-r_win:Conn_position(j,1), Conn_position(j,2)-r_win:Conn_position(j,2));
            patch_quadrant_L_B = I_in(Conn_position(j,1):Conn_position(j,1)+r_win, Conn_position(j,2)-r_win:Conn_position(j,2));
            patch_quadrant_R_B = I_in(Conn_position(j,1):Conn_position(j,1)+r_win, Conn_position(j,2):Conn_position(j,2)+r_win);
            % 
            G_quadrant_R_U = Gradient_analysis_morphology(patch_quadrant_R_U);
            G_quadrant_L_U = Gradient_analysis_morphology(patch_quadrant_L_U);
            G_quadrant_L_B = Gradient_analysis_morphology(patch_quadrant_L_B);
            G_quadrant_R_B = Gradient_analysis_morphology(patch_quadrant_R_B);
            %         
            [G_max_R_U,G_index_R_U] = max(G_quadrant_R_U);
            G_index_diff_R_U = min(abs(6-G_index_R_U),8-abs(6-G_index_R_U));
            [G_max_L_U,G_index_L_U] = max(G_quadrant_L_U);
            G_index_diff_L_U = min(abs(8-G_index_L_U),8-abs(8-G_index_L_U));
            [G_max_L_B,G_index_L_B] = max(G_quadrant_L_B);
            G_index_diff_L_B = min(abs(2-G_index_L_B),8-abs(2-G_index_L_B));
            [G_max_R_B,G_index_R_B] = max(G_quadrant_R_B);
            G_index_diff_R_B = min(abs(4-G_index_R_B),8-abs(4-G_index_R_B));
            % 
            index_sum = G_index_diff_R_U+G_index_diff_L_U+G_index_diff_L_B+G_index_diff_R_B;
            % 
            %
            G_score_R_U = G_quadrant_R_U(6)*0.5 + G_quadrant_R_U(5)*0.25 + G_quadrant_R_U(7)*0.25;
            G_score_L_U = G_quadrant_L_U(8)*0.5 + G_quadrant_L_U(1)*0.25 + G_quadrant_L_U(7)*0.25;
            G_score_L_B = G_quadrant_L_B(2)*0.5 + G_quadrant_L_B(1)*0.25 + G_quadrant_L_B(3)*0.25;
            G_score_R_B = G_quadrant_R_B(4)*0.5 + G_quadrant_R_B(3)*0.25 + G_quadrant_R_B(5)*0.25;
            % ��
            G_factor = 1;
            if (G_index_R_U==G_index_L_U & G_index_L_B==G_index_R_B & G_index_R_U==G_index_L_B)==1  % 
                G_factor = 0;
            end
            if (G_score_R_U<0) + (G_score_L_U<0) + (G_score_L_B<0) + (G_score_R_B<0)>1 % 
                G_factor = 0;
            end
            % 
            G_std = std([G_score_R_U,G_score_L_U,G_score_L_B,G_score_R_B]);
            G_mean = mean([G_score_R_U,G_score_L_U,G_score_L_B,G_score_R_B]);
            % 
            G_score = G_mean/ (1+index_sum);
            Gradient_map(Conn_position(j,1),Conn_position(j,2)) = G_score*G_factor;
        end
    end
    
%%   
end 
%% 
end 